# PERSONA – Full-stack MVP

This is a runnable demo implementing the PERSONA idea: a platform where photographers, editors and clients meet, post work, chat, rate each other, and verify identities.

## Stack
- Backend: Node.js, Express, Prisma (SQLite), JWT, Nodemailer (dev), Socket.IO
- Frontend: React (Vite), Axios, socket.io-client

## Features
- Unique username for each user
- Roles: CLIENT, PHOTOGRAPHER, EDITOR
- Social feed (simple posts)
- Real-time chatrooms via Socket.IO
- Ratings (1–5) between users
- Bookings (create + list mine)
- Verification
  - Clients: email OTP (dev-mode mailer)
  - Photographers/Editors: Aadhaar verification placeholder (simulated: even last digit = verified). Replace with a licensed KUA/eKYC provider before production.

## Quick Start

### Backend
```bash
cd backend
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```
API runs on http://localhost:4000

> To see OTPs during development, run a local SMTP sink such as `python -m smtpd -c DebuggingServer -n localhost:1025`.

### Frontend
```bash
cd ../frontend
npm install
npm run dev
```
Open http://localhost:5173
