import React, { useEffect, useState } from 'react'
import { API, setToken } from './api'
import Login from './pages/Login'
import Register from './pages/Register'
import Feed from './pages/Feed'
import Chat from './pages/Chat'
import Verify from './pages/Verify'
import Profile from './pages/Profile'

export default function App(){
  const [view, setView] = useState('login')
  const [user, setUser] = useState(null)
  const [token, setTok] = useState(localStorage.getItem('token') || '')

  useEffect(()=>{ if(token) setToken(token) }, [token])

  function onLogin({token, user}){
    setTok(token); localStorage.setItem('token', token); setUser(user); setView('feed')
  }

  return (
    <div style={{fontFamily:'Inter, system-ui', padding:20}}>
      <h1>PERSONA</h1>
      <nav style={{display:'flex', gap:8, marginBottom:12}}>
        <button onClick={()=>setView('feed')}>Feed</button>
        <button onClick={()=>setView('chat')}>Chat</button>
        <button onClick={()=>setView('verify')}>Verification</button>
        <button onClick={()=>setView('profile')}>Profile</button>
        <button onClick={()=>{ setTok(''); localStorage.removeItem('token'); setUser(null); setView('login') }}>Logout</button>
      </nav>
      {(!token || !user) && (
        <div style={{display:'flex', gap:16}}>
          <Login onLogin={onLogin} />
          <Register onLogin={onLogin} />
        </div>
      )}
      {token && view==='feed' && <Feed user={user} />}
      {token && view==='chat' && <Chat user={user} />}
      {token && view==='verify' && <Verify user={user} />}
      {token && view==='profile' && <Profile user={user} />}
    </div>
  )
}
