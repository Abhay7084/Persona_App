import axios from 'axios'
export const API = axios.create({ baseURL: 'http://localhost:4000' })
export function setToken(t){ API.defaults.headers.common['Authorization'] = 'Bearer ' + t }
