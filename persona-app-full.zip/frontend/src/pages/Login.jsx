import React, { useState } from 'react'
import { API } from '../api'

export default function Login({ onLogin }){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  return (
    <div style={{border:'1px solid #ddd', padding:12, borderRadius:8}}>
      <h3>Login</h3>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} /><br/>
      <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} /><br/>
      <button onClick={async ()=>{
        const { data } = await API.post('/auth/login',{ email, password })
        onLogin(data)
      }}>Login</button>
    </div>
  )
}
