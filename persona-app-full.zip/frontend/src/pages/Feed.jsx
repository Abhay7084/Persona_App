import React, { useEffect, useState } from 'react'
import { API } from '../api'
import Post from '../components/Post'

export default function Feed({ user }){
  const [posts, setPosts] = useState([])
  const [caption, setCaption] = useState('')

  useEffect(()=>{ 
    (async ()=>{
      const { data } = await API.get('/posts')
      setPosts(data)
    })() 
  }, [])

  async function createPost(){
    const { data } = await API.post('/posts',{ caption, imageUrl:'' })
    setPosts([data, ...posts]); setCaption('')
  }

  return (
    <div>
      <h3>Social Feed</h3>
      <div>
        <input placeholder="Share your latest capture..." value={caption} onChange={e=>setCaption(e.target.value)} />
        <button onClick={createPost}>Post</button>
      </div>
      <div>
        {posts.map(p=> <Post key={p.id} post={p} />)}
      </div>
    </div>
  )
}
