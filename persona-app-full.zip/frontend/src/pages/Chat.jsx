import React, { useEffect, useRef, useState } from 'react'
import { io } from 'socket.io-client'

export default function Chat({ user }){
  const [room, setRoom] = useState('lobby')
  const [msg, setMsg] = useState('')
  const [lines, setLines] = useState([])
  const socketRef = useRef(null)

  useEffect(()=>{
    const s = io('http://localhost:4000')
    socketRef.current = s
    s.emit('join', room)
    s.on('message', (m)=> setLines(prev=>[...prev, m]))
    return ()=> s.disconnect()
  }, [room])

  function send(){
    const m = { from: user?.username, text: msg, at: new Date().toLocaleTimeString() }
    socketRef.current.emit('message', { room, message: m })
    setMsg('')
  }

  return (
    <div>
      <h3>Chatroom</h3>
      <div>
        <input placeholder="Room (e.g., booking-123)" value={room} onChange={e=>setRoom(e.target.value)} />
      </div>
      <div style={{border:'1px solid #ddd', padding:8, height:200, overflow:'auto', margin:'8px 0'}}>
        {lines.map((l,i)=>(<div key={i}><b>{l.from}</b>: {l.text} <small>{l.at}</small></div>))}
      </div>
      <input value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Type message..." />
      <button onClick={send}>Send</button>
    </div>
  )
}
