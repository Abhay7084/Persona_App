import React, { useEffect, useState } from 'react'
import { API } from '../api'

export default function Profile(){
  const [me,setMe] = useState(null)
  useEffect(()=>{ (async ()=>{ const {data} = await API.get('/users/me'); setMe(data) })() },[])
  if(!me) return <div>Loading...</div>
  return (
    <div>
      <h3>My Profile</h3>
      <div><b>Username:</b> @{me.username}</div>
      <div><b>Name:</b> {me.fullName}</div>
      <div><b>Role:</b> {me.role}</div>
      <div><b>Email Verified:</b> {String(me.emailVerified)}</div>
      <div><b>Phone Verified:</b> {String(me.phoneVerified)}</div>
      <div><b>Aadhaar Verified:</b> {String(me.aadhaarVerified)}</div>
    </div>
  )
}
