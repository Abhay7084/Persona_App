import React, { useState } from 'react'
import { API } from '../api'

export default function Register({ onLogin }){
  const [form, setForm] = useState({ email:'', phone:'', password:'', role:'CLIENT', username:'', fullName:'' })
  function set(k,v){ setForm({...form, [k]:v}) }
  return (
    <div style={{border:'1px solid #ddd', padding:12, borderRadius:8}}>
      <h3>Register</h3>
      <input placeholder="Full Name" value={form.fullName} onChange={e=>set('fullName', e.target.value)} /><br/>
      <input placeholder="Unique Username" value={form.username} onChange={e=>set('username', e.target.value)} /><br/>
      <input placeholder="Email" value={form.email} onChange={e=>set('email', e.target.value)} /><br/>
      <input placeholder="Phone" value={form.phone} onChange={e=>set('phone', e.target.value)} /><br/>
      <select value={form.role} onChange={e=>set('role', e.target.value)}>
        <option value="CLIENT">Client</option>
        <option value="PHOTOGRAPHER">Photographer</option>
        <option value="EDITOR">Editor</option>
      </select><br/>
      <input placeholder="Password" type="password" value={form.password} onChange={e=>set('password', e.target.value)} /><br/>
      <button onClick={async ()=>{
        const { data } = await API.post('/auth/register', form)
        onLogin(data)
      }}>Create account</button>
    </div>
  )
}
