import React, { useState } from 'react'
import { API } from '../api'

export default function Verify({ user }){
  const [email, setEmail] = useState('')
  const [code, setCode] = useState('')
  const [aadhaar, setAadhaar] = useState('')

  async function requestOtp(){
    await API.post('/auth/request-otp', { email })
    alert('OTP sent (check dev mailer)')
  }
  async function verifyOtp(){
    const { data } = await API.post('/auth/verify-otp', { email, code })
    alert('Email verified: ' + data.ok)
  }
  async function verifyAadhaar(){
    const { data } = await API.post('/auth/aadhaar-verify', { userId: user.id, aadhaarNumber: aadhaar, consent: true })
    alert('Aadhaar status: ' + (data.ok ? 'verified' : 'rejected'))
  }

  return (
    <div>
      <h3>Verification Center</h3>
      <div style={{border:'1px solid #eee', padding:10, borderRadius:8, marginBottom:8}}>
        <h4>Client Email OTP</h4>
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <button onClick={requestOtp}>Request OTP</button>
        <input placeholder="Enter OTP" value={code} onChange={e=>setCode(e.target.value)} />
        <button onClick={verifyOtp}>Verify</button>
      </div>
      <div style={{border:'1px solid #eee', padding:10, borderRadius:8}}>
        <h4>Photographer/Editor Aadhaar</h4>
        <input placeholder="Aadhaar Number (demo)" value={aadhaar} onChange={e=>setAadhaar(e.target.value)} />
        <button onClick={verifyAadhaar}>Submit for Verification</button>
      </div>
    </div>
  )
}
