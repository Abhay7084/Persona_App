import React from 'react'

export default function Post({ post }){
  return (
    <div style={{border:'1px solid #eee', padding:10, margin:'10px 0', borderRadius:8}}>
      <div style={{fontWeight:'bold'}}>@{post.author?.username || 'user'}</div>
      <div>{post.caption}</div>
    </div>
  )
}
