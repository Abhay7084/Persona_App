import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import { PrismaClient } from '@prisma/client'
import http from 'http'
import { Server } from 'socket.io'

import authRoutes from './routes/auth.js'
import userRoutes from './routes/users.js'
import postRoutes from './routes/posts.js'
import ratingRoutes from './routes/ratings.js'
import bookingRoutes from './routes/bookings.js'

const app = express()
const server = http.createServer(app)
const io = new Server(server, { cors: { origin: process.env.CLIENT_URL || '*' }})

const prisma = new PrismaClient()
app.set('prisma', prisma)
app.set('io', io)

app.use(cors())
app.use(express.json({limit: '5mb'}))

app.get('/', (req,res)=> res.json({status:'ok', service:'PERSONA API'}))

app.use('/auth', authRoutes)
app.use('/users', userRoutes)
app.use('/posts', postRoutes)
app.use('/ratings', ratingRoutes)
app.use('/bookings', bookingRoutes)

io.on('connection', (socket)=>{
  socket.on('join', (room)=> socket.join(room))
  socket.on('message', ({room, message})=>{
    io.to(room).emit('message', message)
  })
})

const PORT = process.env.PORT || 4000
server.listen(PORT, ()=> console.log('API on http://localhost:'+PORT))
