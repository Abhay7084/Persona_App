import { Router } from 'express'
import { authMiddleware } from './middleware.js'

const router = Router()

router.post('/', authMiddleware, async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { revieweeId, score, comment } = req.body
  const r = await prisma.rating.create({ data: { reviewerId: req.user.id, revieweeId, score, comment } })
  res.json(r)
})

router.get('/for/:userId', async (req,res)=>{
  const prisma = req.app.get('prisma')
  const list = await prisma.rating.findMany({ where: { revieweeId: req.params.userId } })
  const avg = list.length ? list.reduce((a,b)=>a+b.score,0)/list.length : 0
  res.json({ average: avg, count: list.length, list })
})

export default router
