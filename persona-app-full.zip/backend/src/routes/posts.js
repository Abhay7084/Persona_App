import { Router } from 'express'
import { authMiddleware } from './middleware.js'

const router = Router()

router.get('/', async (req,res)=>{
  const prisma = req.app.get('prisma')
  const posts = await prisma.post.findMany({ include: { author: true }, orderBy: { createdAt: 'desc' }, take: 50 })
  res.json(posts)
})

router.post('/', authMiddleware, async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { caption, imageUrl } = req.body
  const p = await prisma.post.create({ data: { caption, imageUrl, authorId: req.user.id } })
  res.json(p)
})

export default router
