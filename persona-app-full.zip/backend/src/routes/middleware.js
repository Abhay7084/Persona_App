import jwt from 'jsonwebtoken'

export const authMiddleware = (req, res, next)=>{
  const auth = req.headers.authorization || ''
  const token = auth.startsWith('Bearer ') ? auth.substring(7) : null
  if(!token) return res.status(401).json({error:'missing token'})
  try{
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'devsecret')
    req.user = payload
    next()
  }catch(e){
    return res.status(401).json({error:'invalid token'})
  }
}
