import { Router } from 'express'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import nodemailer from 'nodemailer'

const router = Router()

const mailer = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
})

router.post('/register', async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { email, phone, password, role, username, fullName } = req.body
  if(!email || !password || !role || !username || !fullName) return res.status(400).json({error:'missing fields'})
  const exists = await prisma.user.findFirst({ where: { OR: [{email}, {username}] } })
  if(exists) return res.status(400).json({error:'email or username already in use'})
  const passwordHash = await bcrypt.hash(password, 10)
  const user = await prisma.user.create({ data: { email, phone, passwordHash, role, username, fullName } })
  const token = jwt.sign({ id: user.id, role: user.role, username: user.username }, process.env.JWT_SECRET || 'devsecret')
  res.json({ token, user })
})

router.post('/login', async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { email, password } = req.body
  const user = await prisma.user.findUnique({ where: { email } })
  if(!user) return res.status(401).json({error:'invalid credentials'})
  const ok = await bcrypt.compare(password, user.passwordHash)
  if(!ok) return res.status(401).json({error:'invalid credentials'})
  const token = jwt.sign({ id: user.id, role: user.role, username: user.username }, process.env.JWT_SECRET || 'devsecret')
  res.json({ token, user })
})

// Email OTP for clients
router.post('/request-otp', async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { email } = req.body
  const user = await prisma.user.findUnique({ where: { email } })
  if(!user) return res.status(404).json({error:'user not found'})
  const code = String(Math.floor(100000 + Math.random()*900000))
  const expires = new Date(Date.now() + 10*60*1000)
  await prisma.oTP.create({ data: { userId: user.id, channel: 'email', code, expiresAt: expires } })
  try {
    await mailer.sendMail({ from:'no-reply@persona.local', to: email, subject:'PERSONA OTP', text:`Your OTP is ${code}` })
  } catch(e){ /* dev mode no-op */ }
  res.json({ ok: true })
})

router.post('/verify-otp', async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { email, code } = req.body
  const user = await prisma.user.findUnique({ where: { email } })
  if(!user) return res.status(404).json({error:'user not found'})
  const otp = await prisma.oTP.findFirst({ where: { userId: user.id, channel: 'email', code } })
  if(!otp || otp.expiresAt < new Date()) return res.status(400).json({error:'invalid or expired'})
  await prisma.oTP.delete({ where: { id: otp.id } })
  const updated = await prisma.user.update({ where: { id: user.id }, data: { emailVerified: true } })
  res.json({ ok: true, user: updated })
})

// Aadhaar verification placeholder
router.post('/aadhaar-verify', async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { userId, aadhaarNumber, consent } = req.body
  if(!consent) return res.status(400).json({error:'consent required'})
  const ok = /\d$/.test(aadhaarNumber) && parseInt(aadhaarNumber.slice(-1)) % 2 === 0
  const data = { verificationStatus: ok ? 'verified' : 'rejected', aadhaarVerified: !!ok }
  const updated = await prisma.user.update({ where: { id: userId }, data })
  res.json({ ok, user: updated })
})

export default router
