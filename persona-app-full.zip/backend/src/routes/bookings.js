import { Router } from 'express'
import { authMiddleware } from './middleware.js'

const router = Router()

router.post('/', authMiddleware, async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { creatorId, date, notes } = req.body
  const b = await prisma.booking.create({ data: { clientId: req.user.id, creatorId, date: new Date(date), notes } })
  res.json(b)
})

router.get('/me', authMiddleware, async (req,res)=>{
  const prisma = req.app.get('prisma')
  const my = await prisma.booking.findMany({ where: { OR: [{ clientId: req.user.id }, { creatorId: req.user.id }] }, orderBy: { createdAt: 'desc' } })
  res.json(my)
})

export default router
