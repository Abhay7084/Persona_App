import { Router } from 'express'
import { authMiddleware } from './middleware.js'

const router = Router()

router.get('/me', authMiddleware, async (req,res)=>{
  const prisma = req.app.get('prisma')
  const me = await prisma.user.findUnique({ where: { id: req.user.id }, include: { portfolios:true } })
  res.json(me)
})

router.get('/search', async (req,res)=>{
  const prisma = req.app.get('prisma')
  const { q, role } = req.query
  const users = await prisma.user.findMany({
    where: {
      role: role || undefined,
      OR: q ? [
        { username: { contains: q, mode: 'insensitive' } },
        { fullName: { contains: q, mode: 'insensitive' } },
      ] : undefined
    },
    take: 20
  })
  res.json(users)
})

export default router
